/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplodetestedeunidade.teste;

import com.mycompany.exemplodetestedeunidade.dao.PessoaDAO;
import com.mycompany.exemplodetestedeunidade.repository.PessoaRepository;
import com.mycompany.exemplodetestedeunidade.utils.Response;
import java.util.Date;
import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author 189435
 */
public class PessoaRepositoryTest {

    private PessoaRepository pessoaRepo;

    @Before
    public void init() {

        pessoaRepo = new PessoaRepository();

    }

    @Test
    public void getAll() {

        List<PessoaDAO> pessoaList = pessoaRepo.getAll();
        Assert.assertEquals(0, pessoaList.size());

        pessoaRepo.save(new PessoaDAO("nome", "exemplo@email.com", "123456", new Date()));
        
        pessoaList = pessoaRepo.getAll();
        Assert.assertEquals(1, pessoaList.size());

    }

    @Test
    public void getByIdNotFound() {

        PessoaDAO res = pessoaRepo.getPessoaById("S");

        Assert.assertEquals(res.getId(), null);

    }

    @Test
    public void getByIdFound() {

        pessoaRepo.save(new PessoaDAO("nome", "exemplo@email.com", "123456", new Date()));

        List<PessoaDAO> pessoaList = pessoaRepo.getAll();

        String validId = null;

        for (PessoaDAO p : pessoaList) {

            validId = p.getId();

        }

        PessoaDAO p = pessoaRepo.getPessoaById(validId);

        Assert.assertNotEquals(null, p.getId());

    }

    @Test
    public void saveInvalidPessoa() {
        
        Response res = pessoaRepo.save(new PessoaDAO("nome", "exemplo@email.com", "1234", new Date()));
     
        Assert.assertEquals( Boolean.FALSE, res.getStatus() );
        Assert.assertEquals( true, res.getMessage().contains("senha") );
        
        res = pessoaRepo.save(new PessoaDAO("nome", "exemplo", "123456", new Date()));
     
        Assert.assertEquals( Boolean.FALSE, res.getStatus() );
        Assert.assertEquals( true, res.getMessage().contains("e-mail") );
        
    }
    
}
