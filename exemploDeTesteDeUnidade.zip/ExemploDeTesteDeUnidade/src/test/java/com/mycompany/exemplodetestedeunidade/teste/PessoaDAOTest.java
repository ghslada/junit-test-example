/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplodetestedeunidade.teste;

import com.mycompany.exemplodetestedeunidade.dao.PessoaDAO;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author 189435
 */
public class PessoaDAOTest {
    
    private PessoaDAO pessoa;
    
    @Before
    public void init() {
        SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy"); //você pode usar outras máscaras
        String data = "21/09/2030";
        Date dataNascimento = new Date();
        try {
            dataNascimento = sdf.parse(data);
        } catch (ParseException ex) {
            Logger.getLogger(PessoaDAOTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        pessoa = new PessoaDAO("nome", "exemplo@email.com", "123", dataNascimento );
    }
    
    @Test
    public void getIdEqualsNull() {

        Assert.assertEquals( pessoa.getId(), null );
        
    }
    
    @Test
    public void getId() {
        
        pessoa.setId("1");
        Assert.assertEquals( pessoa.getId(), "1" );
        
    }
    
    @Test
    public void getEmail() {
        
        Assert.assertEquals( "exemplo@email.com", pessoa.getEmail() );
        
    }
    
    @Test
    public void getDataNascimento() {
        
        Assert.assertNotEquals( pessoa.getDataNascimento(), new Date() );
        
    }
        
}
