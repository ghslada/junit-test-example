/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplodetestedeunidade;

/**
 *
 * @author 189435
 */
public class Main {
    public static void main(String[] args) {
//    ProdutoRepositorio repositorio = new ProdutoRepositorio();;;
//    Produto produto = new Produto("Aparelho de barbear", 39.9, ...);
//    repositorio.salvar(produto);
}
}
