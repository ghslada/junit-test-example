/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplodetestedeunidade.repository;

import com.mycompany.exemplodetestedeunidade.dao.PessoaDAO;
import com.mycompany.exemplodetestedeunidade.utils.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 *
 * @author 189435
 */
public class PessoaRepository {

    private List<PessoaDAO> pessoaRepository;

    public PessoaRepository() {

        pessoaRepository = new ArrayList<>();

    }

    public List<PessoaDAO> getAll() {

        return pessoaRepository;

    }

    public PessoaDAO getPessoaById(String id) {

        PessoaDAO pessoa = new PessoaDAO();

        for (PessoaDAO pessoaExistenteNoBD : pessoaRepository) {

            if (pessoaExistenteNoBD.getId() == id) {

                pessoa = pessoaExistenteNoBD;

            }

        }

        return pessoa;

    }

    public Response save(PessoaDAO pessoa) {

        String uniqueID = UUID.randomUUID().toString();

        pessoa.setId(uniqueID);

        Response response = new Response();

        response.setStatus(true);

        response.setMessage("Sucesso ao salvar pessoa no banco de dados.");

        for (PessoaDAO pessoaExistenteNoBD : pessoaRepository) {

            if (pessoaExistenteNoBD.getId() == pessoa.getId()
                    || pessoaExistenteNoBD.getEmail() == pessoa.getEmail()) {

                response.setStatus(false);

                response.setMessage("E-mail já existe no banco de dados.");

            }
            
            if (pessoa.getEmail().length() < 10) {

                response.setStatus(false);

                response.setMessage("E-mail inválido. o endereço de e-mail precisa ter no mínimo 10 caracteres.");

            }
            
            if (pessoa.getSenha().length() < 6) {

                response.setStatus(false);

                response.setMessage("Senha inválida. a senha precisa ter no mínimo 6 caracteres.");

            } 
            
        }

        if (response.getStatus()) {

            pessoaRepository.add(pessoa);

        }

        return response;

    }

    public Response update(PessoaDAO pessoa) {

        Response response = new Response();

        response.setStatus(false);

        response.setMessage("ID não encontrado.");

        for (PessoaDAO pessoaExistenteNoBD : pessoaRepository) {

            if (pessoaExistenteNoBD.getId() == pessoa.getId()) {

                pessoaExistenteNoBD.setNome(pessoa.getNome());

                pessoaExistenteNoBD.setSenha(pessoa.getSenha());

                pessoaExistenteNoBD.setDataNascimento(pessoa.getDataNascimento());

                response.setStatus(true);

                response.setMessage("Sucesso ao editar dados da pessoa.");

            }

        }

        return response;

    }

    public Response delete(String id) {

        Response response = new Response();

        response.setStatus(false);

        response.setMessage("ID não encontrado.");

        int idx = 0;

        for (PessoaDAO pessoaExistenteNoBD : pessoaRepository) {

            if (pessoaExistenteNoBD.getId() == id) {

                pessoaRepository.remove(idx);

                response.setStatus(true);

                response.setMessage("Sucesso ao excluir pessoa.");

            }

            idx++;

        }

        return response;

    }

}
