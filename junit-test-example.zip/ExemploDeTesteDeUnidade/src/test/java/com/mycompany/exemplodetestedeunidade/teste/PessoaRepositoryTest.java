/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplodetestedeunidade.teste;

import com.mycompany.exemplodetestedeunidade.dao.PessoaDAO;
import com.mycompany.exemplodetestedeunidade.repository.PessoaRepository;
import com.mycompany.exemplodetestedeunidade.utils.Response;
import java.util.Date;
import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author 189435
 */
public class PessoaRepositoryTest {

    private PessoaRepository pessoaRepo;

    @Before
    public void init() {

        pessoaRepo = new PessoaRepository();

    }

    @Test
    public void getAll() {

        List<PessoaDAO> pessoaList = pessoaRepo.getAll();
        Assert.assertEquals(0, pessoaList.size());

        pessoaRepo.save(new PessoaDAO("nome", "exemplo@email.com", "123456", new Date()));
        
        pessoaList = pessoaRepo.getAll();
        Assert.assertEquals(1, pessoaList.size());

    }

    @Test
    public void getByIdNotFound() {

        PessoaDAO res = pessoaRepo.getPessoaById("S");

        Assert.assertEquals(res.getId(), null);

    }

    @Test
    public void getByIdFound() {

        pessoaRepo.save(new PessoaDAO("nome", "exemplo@email.com", "123456", new Date()));

        List<PessoaDAO> pessoaList = pessoaRepo.getAll();

        String validId = null;

        for (PessoaDAO p : pessoaList) {

            validId = p.getId();

        }

        PessoaDAO p = pessoaRepo.getPessoaById(validId);

        Assert.assertNotEquals(null, p.getId());

    }

    @Test
    public void saveInvalidPessoa() {
        
        Response res = pessoaRepo.save(new PessoaDAO("nome", "exemplo@email.com", "1234", new Date()));
     
        Assert.assertEquals( false, res.getStatus() );
        Assert.assertEquals( true, res.getMessage().contains("senha") );
        
        res = pessoaRepo.save(new PessoaDAO("nome", "exemplo", "123456", new Date()));
     
        Assert.assertEquals( false, res.getStatus() );
        Assert.assertEquals( true, res.getMessage().contains("e-mail") );
        
    }
    
        @Test
    public void saveValidPessoa() {
        
        Response res = pessoaRepo.save(new PessoaDAO("nome", "exemplo@email.com", "123456", new Date()));
     
        Assert.assertEquals( true, res.getStatus() );
        Assert.assertEquals( true, res.getMessage().contains("Sucesso") );
//        Assert.assertEquals( true, res.getMessage().contains("e-mail") );;
        
    }

    @Test
    public void updateInvalidPessoa() {

        pessoaRepo.save(new PessoaDAO("nome", "exemplo@email.com", "123456", new Date()));

        List<PessoaDAO> pessoaList = pessoaRepo.getAll();

        PessoaDAO invalidPessoa = null;

        for (PessoaDAO p : pessoaList) {

            invalidPessoa = p;
            invalidPessoa.setId("tset");
            invalidPessoa.setEmail("123");
        }

        
        Response p = pessoaRepo.update(invalidPessoa);

        Assert.assertNotEquals(false, p.getStatus()==false );
        Assert.assertNotEquals(true, p.getMessage().contains("ID não encontrado.") );
        
    }    
    
    @Test
    public void updateValidPessoa() {

        pessoaRepo.save(new PessoaDAO("nome", "exemplo@email.com", "123456", new Date()));

        List<PessoaDAO> pessoaList = pessoaRepo.getAll();

        PessoaDAO validPessoa = new PessoaDAO();

        for (PessoaDAO p : pessoaList) {

            validPessoa.setId(p.getId());
            validPessoa.setEmail(p.getEmail());
            validPessoa.setSenha(p.getSenha());
            validPessoa.setDataNascimento(p.getDataNascimento());
            
        }

        
        Response p = pessoaRepo.update(validPessoa);

        Assert.assertEquals(true, p.getStatus());
        Assert.assertEquals(true, p.getMessage().contains("Sucesso") );
        
    }    
    
    @Test
    public void deleteInvalidId() {
        pessoaRepo.save(new PessoaDAO("nome", "exemplo@email.com", "123456", new Date()));

        List<PessoaDAO> pessoaList = pessoaRepo.getAll();

        PessoaDAO validPessoa = new PessoaDAO();

        for (PessoaDAO p : pessoaList) {

            validPessoa.setId("INVALID");
            validPessoa.setEmail(p.getEmail());
            validPessoa.setSenha(p.getSenha());
            validPessoa.setDataNascimento(p.getDataNascimento());
            
        }

        Response p = pessoaRepo.delete(validPessoa.getId());

        Assert.assertEquals(false, p.getStatus());
        Assert.assertEquals(true, p.getMessage().contains("ID não encontrado.") );
        
    }
    
    @Test
    public void deleteValidId() {
        pessoaRepo.save(new PessoaDAO("nome", "exemplo@email.com", "123456", new Date()));

        List<PessoaDAO> pessoaList = pessoaRepo.getAll();

        PessoaDAO validPessoa = new PessoaDAO();

        for (PessoaDAO p : pessoaList) {

            validPessoa.setId(p.getId());
            validPessoa.setEmail(p.getEmail());
            validPessoa.setSenha(p.getSenha());
            validPessoa.setDataNascimento(p.getDataNascimento());
            
        }

        System.out.println("Pessoa ID: "+validPessoa.getId());
        Response p = pessoaRepo.delete(validPessoa.getId());
        System.out.println("MSG: " + p.getMessage() );
        //Assert.assertEquals(true, p.getStatus() );
        Assert.assertEquals(true, p.getMessage().contains("Sucesso") );
        
    }
}
